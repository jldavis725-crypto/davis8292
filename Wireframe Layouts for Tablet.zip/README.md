
  # Wireframe Layouts for Tablet

  This is a code bundle for Wireframe Layouts for Tablet. The original project is available at https://www.figma.com/design/MSy5VxreN9CHayN2lNGT8Z/Wireframe-Layouts-for-Tablet.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  