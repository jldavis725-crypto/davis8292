import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from "lucide-react";

interface FooterProps {
  variant?: "default" | "contact";
}

export function Footer({ variant = "default" }: FooterProps) {
  if (variant === "contact") {
    return (
      <footer className="bg-[#2d3748] text-white">
        <div className="container mx-auto px-6 py-12">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Contact Info */}
            <div>
              <h3 className="mb-4">Contact Us</h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5" />
                  <span>+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5" />
                  <span>info@brookstownfurniture.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5" />
                  <span>123 Main Street, Brooks Town, ST 12345</span>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h3 className="mb-4">Quick Links</h3>
              <div className="space-y-2">
                <div><a href="#" className="hover:text-[#d69e2e] transition-colors">About Us</a></div>
                <div><a href="#" className="hover:text-[#d69e2e] transition-colors">Our Process</a></div>
                <div><a href="#" className="hover:text-[#d69e2e] transition-colors">Custom Orders</a></div>
                <div><a href="#" className="hover:text-[#d69e2e] transition-colors">Delivery Info</a></div>
              </div>
            </div>

            {/* Social Links */}
            <div>
              <h3 className="mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <Facebook className="h-6 w-6 cursor-pointer hover:text-[#d69e2e] transition-colors" />
                <Instagram className="h-6 w-6 cursor-pointer hover:text-[#d69e2e] transition-colors" />
                <Twitter className="h-6 w-6 cursor-pointer hover:text-[#d69e2e] transition-colors" />
              </div>
            </div>
          </div>

          <div className="border-t border-white/20 mt-8 pt-8 text-center">
            <p>&copy; 2024 Brooks Town Home Furnishings. All rights reserved.</p>
          </div>
        </div>
      </footer>
    );
  }

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <h3 className="text-[#d69e2e] mb-4">Brooks Town Home Furnishings</h3>
            <p className="text-gray-400">
              Quality furniture for every home. Serving the community with style and comfort since 2005.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="mb-4">Quick Links</h4>
            <div className="space-y-2">
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">About Us</a></div>
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Collections</a></div>
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Custom Design</a></div>
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Care Guide</a></div>
            </div>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="mb-4">Customer Service</h4>
            <div className="space-y-2">
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Shipping Info</a></div>
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Returns</a></div>
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Size Guide</a></div>
              <div><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact</a></div>
            </div>
          </div>

          {/* Social Links */}
          <div>
            <h4 className="mb-4">Connect</h4>
            <div className="flex space-x-4">
              <Facebook className="h-6 w-6 text-gray-400 cursor-pointer hover:text-[#d69e2e] transition-colors" />
              <Instagram className="h-6 w-6 text-gray-400 cursor-pointer hover:text-[#d69e2e] transition-colors" />
              <Twitter className="h-6 w-6 text-gray-400 cursor-pointer hover:text-[#d69e2e] transition-colors" />
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">&copy; 2024 Brooks Town Home Furnishings. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}