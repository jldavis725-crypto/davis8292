import { MapPin, Phone, Mail, Clock, MessageSquare, Send } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";

export function ContactPage() {
  const storeHours = [
    { day: "Monday - Friday", hours: "9:00 AM - 8:00 PM" },
    { day: "Saturday", hours: "9:00 AM - 6:00 PM" },
    { day: "Sunday", hours: "11:00 AM - 5:00 PM" },
    { day: "Holidays", hours: "Varies (Call ahead)" }
  ];

  return (
    <div className="pt-20 bg-[#faf5f0] min-h-screen">
      {/* Hero Section */}
      <section className="py-16 bg-[#1a365d] text-white">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl mb-4">Get in Touch</h1>
          <p className="text-xl text-gray-300">
            We're here to help you create the perfect home. Contact us today for personalized service.
          </p>
        </div>
      </section>

      {/* Contact Cards */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {/* Address */}
            <Card className="text-center bg-white shadow-lg">
              <CardContent className="p-8">
                <MapPin className="h-12 w-12 text-[#1a365d] mx-auto mb-4" />
                <h3 className="text-xl mb-3 text-[#1a365d]">Visit Our Showroom</h3>
                <p className="text-[#718096] mb-2">123 Main Street</p>
                <p className="text-[#718096] mb-2">Brooks Town, ST 12345</p>
                <Button 
                  variant="outline" 
                  className="mt-4 text-[#1a365d] border-[#1a365d] hover:bg-[#1a365d] hover:text-white"
                >
                  Get Directions
                </Button>
              </CardContent>
            </Card>

            {/* Phone */}
            <Card className="text-center bg-white shadow-lg">
              <CardContent className="p-8">
                <Phone className="h-12 w-12 text-[#1a365d] mx-auto mb-4" />
                <h3 className="text-xl mb-3 text-[#1a365d]">Call Us</h3>
                <p className="text-[#718096] mb-2">(555) 123-FURN</p>
                <p className="text-[#718096] mb-2">(555) 123-3876</p>
                <Button 
                  variant="outline" 
                  className="mt-4 text-[#1a365d] border-[#1a365d] hover:bg-[#1a365d] hover:text-white"
                >
                  Call Now
                </Button>
              </CardContent>
            </Card>

            {/* Email */}
            <Card className="text-center bg-white shadow-lg">
              <CardContent className="p-8">
                <Mail className="h-12 w-12 text-[#1a365d] mx-auto mb-4" />
                <h3 className="text-xl mb-3 text-[#1a365d]">Email Us</h3>
                <p className="text-[#718096] mb-2">info@brookstownfurniture.com</p>
                <p className="text-[#718096] mb-2">sales@brookstownfurniture.com</p>
                <Button 
                  variant="outline" 
                  className="mt-4 text-[#1a365d] border-[#1a365d] hover:bg-[#1a365d] hover:text-white"
                >
                  Send Email
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Contact Form */}
            <div className="lg:col-span-2">
              <Card className="bg-white shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <MessageSquare className="h-6 w-6 text-[#1a365d] mr-3" />
                    <h2 className="text-2xl text-[#1a365d]">Send Us a Message</h2>
                  </div>
                  
                  <form className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name" className="text-[#1a365d]">Full Name *</Label>
                        <Input
                          id="name"
                          type="text"
                          placeholder="Enter your full name"
                          className="mt-2"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="email" className="text-[#1a365d]">Email Address *</Label>
                        <Input
                          id="email"
                          type="email"
                          placeholder="Enter your email"
                          className="mt-2"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="phone" className="text-[#1a365d]">Phone Number</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="Enter your phone number"
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="subject" className="text-[#1a365d]">Subject</Label>
                        <Input
                          id="subject"
                          type="text"
                          placeholder="What can we help you with?"
                          className="mt-2"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="message" className="text-[#1a365d]">Message *</Label>
                      <Textarea
                        id="message"
                        placeholder="Tell us about your furniture needs, design questions, or any other inquiries..."
                        className="mt-2 min-h-[120px]"
                        required
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <input type="checkbox" id="newsletter" className="rounded" />
                      <Label htmlFor="newsletter" className="text-sm text-[#718096]">
                        Subscribe to our newsletter for the latest deals and design tips
                      </Label>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-[#1a365d] hover:bg-[#2c5282] text-white"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-8">
              {/* Store Hours */}
              <Card className="bg-white shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <Clock className="h-6 w-6 text-[#1a365d] mr-3" />
                    <h2 className="text-2xl text-[#1a365d]">Store Hours</h2>
                  </div>
                  
                  <div className="space-y-3">
                    {storeHours.map((schedule, index) => (
                      <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                        <span className="text-[#718096]">{schedule.day}</span>
                        <span className="text-[#1a365d]">{schedule.hours}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Map */}
              <Card className="bg-white shadow-lg">
                <CardContent className="p-8">
                  <h2 className="text-2xl mb-6 text-[#1a365d]">Find Us</h2>
                  <div className="aspect-[4/3] bg-gray-200 rounded-lg flex items-center justify-center">
                    <div className="text-center text-[#718096]">
                      <MapPin className="h-12 w-12 mx-auto mb-2" />
                      <p>Interactive Map Coming Soon</p>
                    </div>
                  </div>
                  <div className="mt-4 flex gap-4">
                    <Button variant="outline" className="flex-1 text-[#1a365d] border-[#1a365d]">
                      View on Google Maps
                    </Button>
                    <Button variant="outline" className="flex-1 text-[#1a365d] border-[#1a365d]">
                      Get Directions
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Additional Services */}
              <Card className="bg-white shadow-lg">
                <CardContent className="p-8">
                  <h2 className="text-2xl mb-6 text-[#1a365d]">Our Services</h2>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-[#1a365d] rounded-full mt-2"></div>
                      <div>
                        <h4 className="text-[#1a365d] mb-1">Free Design Consultation</h4>
                        <p className="text-[#718096] text-sm">Our experts help you create the perfect space</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-[#1a365d] rounded-full mt-2"></div>
                      <div>
                        <h4 className="text-[#1a365d] mb-1">White Glove Delivery</h4>
                        <p className="text-[#718096] text-sm">Professional delivery and setup service</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-[#1a365d] rounded-full mt-2"></div>
                      <div>
                        <h4 className="text-[#1a365d] mb-1">Financing Available</h4>
                        <p className="text-[#718096] text-sm">Flexible payment options to fit your budget</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-[#1a365d] text-white text-center">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl mb-4">Ready to Visit Our Showroom?</h2>
          <p className="text-xl mb-8 text-gray-300">
            See our furniture in person and get expert advice from our design team.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-[#1a365d] hover:bg-gray-100">
              Schedule Appointment
            </Button>
            <Button className="bg-[#d69e2e] hover:bg-[#b7791f] text-white">
              Call (555) 123-FURN
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}