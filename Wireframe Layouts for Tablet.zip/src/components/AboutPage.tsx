import { Users, Award, Clock, MapPin } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function AboutPage() {
  const teamMembers = [
    {
      name: "Sarah Brooks",
      role: "Owner & Founder",
      bio: "With over 20 years in furniture design, Sarah founded Brooks Town to bring quality home furnishings to the community.",
      image: "https://images.unsplash.com/photo-1691426445669-661d566447b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXJuaXR1cmUlMjBzdG9yZSUyMG93bmVyJTIwdGVhbXxlbnwxfHx8fDE3NTkyMzg5Mzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      name: "Michael Chen",
      role: "Design Consultant", 
      bio: "Michael helps customers create beautiful spaces that reflect their personal style and functional needs.",
      image: "https://images.unsplash.com/photo-1663756915436-c6842b9d3eb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzb2ZhJTIwbGl2aW5nJTIwcm9vbXxlbnwxfHx8fDE3NTkyMzgzOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      name: "Jennifer Martinez",
      role: "Customer Service Manager",
      bio: "Jennifer ensures every customer receives exceptional service from selection to delivery and beyond.",
      image: "https://images.unsplash.com/photo-1680503146454-04ac81a63550?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWRyb29tJTIwZnVybml0dXJlJTIwYmVkfGVufDF8fHx8MTc1OTEzNzE0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  const milestones = [
    { year: "2005", event: "Brooks Town Home Furnishings founded" },
    { year: "2010", event: "Expanded to 15,000 sq ft showroom" },
    { year: "2015", event: "Introduced custom design services" },
    { year: "2020", event: "Added virtual consultation options" },
    { year: "2024", event: "Celebrating 19 years serving the community" }
  ];

  return (
    <div className="pt-20 bg-white min-h-screen">
      {/* Hero Section */}
      <section className="py-16 bg-[#edf2f7]">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl mb-4 text-[#1a365d]">About Brooks Town Home Furnishings</h1>
          <p className="text-xl text-[#718096] max-w-3xl mx-auto">
            For nearly two decades, we've been helping families create beautiful, comfortable homes 
            with quality furniture and personalized design services.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl mb-6 text-[#1a365d]">Our Story</h2>
              <div className="space-y-4 text-[#718096]">
                <p>
                  Brooks Town Home Furnishings began in 2005 with a simple vision: to provide 
                  high-quality furniture and exceptional customer service to our local community. 
                  What started as a small showroom has grown into the area's premier destination 
                  for home furnishings.
                </p>
                <p>
                  We believe that your home should reflect your personality and lifestyle. 
                  That's why we carefully curate our collection to include pieces that combine 
                  style, comfort, and durability. From contemporary to traditional, we have 
                  something for every taste and budget.
                </p>
                <p>
                  Our commitment goes beyond just selling furniture. We offer design consultations, 
                  delivery services, and ongoing support to ensure you're completely satisfied 
                  with your purchase for years to come.
                </p>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1696774566203-b5883558badd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmdXJuaXR1cmUlMjBzaG93cm9vbSUyMGludGVyaW9yfGVufDF8fHx8MTc1OTE1NDAwN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Brooks Town showroom interior"
                className="w-full h-[400px] object-cover rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-[#edf2f7]">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl text-center mb-12 text-[#1a365d]">Our Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-8">
                <Award className="h-12 w-12 text-[#d69e2e] mx-auto mb-4" />
                <h3 className="text-xl mb-3 text-[#1a365d]">Quality First</h3>
                <p className="text-[#718096]">
                  We partner with trusted manufacturers to ensure every piece meets our high standards for quality and durability.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <Users className="h-12 w-12 text-[#d69e2e] mx-auto mb-4" />
                <h3 className="text-xl mb-3 text-[#1a365d]">Customer Focus</h3>
                <p className="text-[#718096]">
                  Your satisfaction is our priority. We provide personalized service from selection through delivery and beyond.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-8">
                <MapPin className="h-12 w-12 text-[#d69e2e] mx-auto mb-4" />
                <h3 className="text-xl mb-3 text-[#1a365d]">Community Commitment</h3>
                <p className="text-[#718096]">
                  As a local business, we're invested in our community and support local charities and events.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl text-center mb-12 text-[#1a365d]">Meet Our Team</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="relative w-32 h-32 mx-auto mb-4">
                    <ImageWithFallback
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover rounded-full"
                    />
                  </div>
                  <h3 className="text-xl mb-2 text-[#1a365d]">{member.name}</h3>
                  <p className="text-[#d69e2e] mb-3">{member.role}</p>
                  <p className="text-[#718096] text-sm">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 bg-[#edf2f7]">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl text-center mb-12 text-[#1a365d]">Our Journey</h2>
          <div className="max-w-3xl mx-auto">
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex items-center">
                  <div className="flex-shrink-0 w-16 h-16 bg-[#1a365d] text-white rounded-full flex items-center justify-center mr-6">
                    <Clock className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-xl text-[#1a365d] mb-1">{milestone.year}</h3>
                    <p className="text-[#718096]">{milestone.event}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-[#1a365d] text-white text-center">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl mb-4">Ready to Transform Your Home?</h2>
          <p className="text-xl mb-8 text-gray-300">
            Visit our showroom today and let our design experts help you create the perfect space.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-[#d69e2e] hover:bg-[#b7791f] text-white px-8 py-3 rounded-lg transition-colors">
              Schedule Consultation
            </button>
            <button className="border border-white text-white hover:bg-white hover:text-[#1a365d] px-8 py-3 rounded-lg transition-colors">
              Visit Our Showroom
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}