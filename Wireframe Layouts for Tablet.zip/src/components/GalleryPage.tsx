import { useState } from "react";
import { Pin, Heart, Share2, ArrowUp } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function GalleryPage() {
  const [activeFilter, setActiveFilter] = useState("all");

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const categories = [
    { id: "all", name: "All", count: 24 },
    { id: "living", name: "Living Rooms", count: 8 },
    { id: "bedroom", name: "Bedrooms", count: 8 },
    { id: "dining", name: "Dining Rooms", count: 8 }
  ];

  const galleryItems = [
    {
      id: 1,
      title: "Modern Minimalist Living",
      category: "living",
      image: "https://images.unsplash.com/photo-1705321963943-de94bb3f0dd3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBpbnRlcmlvciUyMGRlc2lnbiUyMGxpdmluZyUyMHJvb218ZW58MXx8fHwxNzU5MTMwNzE0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      designer: "Luxura Design Team",
      likes: 142,
      pins: 89
    },
    {
      id: 2,
      title: "Cozy Bedroom Sanctuary",
      category: "bedroom",
      image: "https://images.unsplash.com/photo-1625579002297-aeebbf69de89?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBiZWRyb29tJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzU5MTIzNDc0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      designer: "Emily Chen",
      likes: 98,
      pins: 67
    },
    {
      id: 3,
      title: "Elegant Dining Experience",
      category: "dining",
      image: "https://images.unsplash.com/photo-1758448500631-644bb3c1c942?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwZGluaW5nJTIwcm9vbSUyMGRlc2lnbnxlbnwxfHx8fDE3NTkxMzAzNDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      designer: "Marcus Rivera",
      likes: 156,
      pins: 92
    },
    {
      id: 4,
      title: "Contemporary Living Space",
      category: "living",
      image: "https://images.unsplash.com/photo-1663756915436-c6842b9d3eb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzb2ZhJTIwbGl2aW5nJTIwcm9vbXxlbnwxfHx8fDE3NTkyMzgzOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      designer: "Sarah Kim",
      likes: 201,
      pins: 134
    },
    {
      id: 5,
      title: "Serene Master Suite",
      category: "bedroom",
      image: "https://images.unsplash.com/photo-1680503146454-04ac81a63550?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWRyb29tJTIwZnVybml0dXJlJTIwYmVkfGVufDF8fHx8MTc1OTEzNzE0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      designer: "Alex Thompson",
      likes: 87,
      pins: 56
    },
    {
      id: 6,
      title: "Family Dining Haven",
      category: "dining",
      image: "https://images.unsplash.com/photo-1547062200-f195b1c77e30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaW5pbmclMjByb29tJTIwdGFibGV8ZW58MXx8fHwxNzU5MjIwNDg0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      designer: "Lisa Park",
      likes: 123,
      pins: 78
    }
  ];

  const filteredItems = activeFilter === "all" 
    ? galleryItems 
    : galleryItems.filter(item => item.category === activeFilter);

  return (
    <div className="pt-20 bg-white min-h-screen">
      {/* Sticky Top Nav */}
      <div className="sticky top-20 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => {
                    setActiveFilter(category.id);
                    if (category.id !== "all") {
                      scrollToSection(category.id);
                    }
                  }}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    activeFilter === category.id
                      ? "bg-teal-600 text-white"
                      : "text-gray-700 hover:text-teal-600"
                  }`}
                >
                  {category.name} ({category.count})
                </button>
              ))}
            </div>
            
            <Button
              onClick={scrollToTop}
              variant="outline"
              size="sm"
              className="text-teal-600 border-teal-600 hover:bg-teal-50"
            >
              <ArrowUp className="h-4 w-4 mr-2" />
              Back to Top
            </Button>
          </div>
        </div>
      </div>

      {/* Gallery Header */}
      <section className="py-16 bg-[#F5F5F5]">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl mb-4 text-[#8D6E63]">Design Gallery</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Explore our curated collection of stunning interior designs. 
            Get inspired by real spaces created with Luxura furniture.
          </p>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                id={item.category}
                className="group relative bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300">
                    <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <Button
                        size="sm"
                        className="bg-white text-[#8D6E63] hover:bg-gray-100 mr-2"
                      >
                        <Pin className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        className="bg-white text-red-500 hover:bg-gray-100 mr-2"
                      >
                        <Heart className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        className="bg-white text-teal-600 hover:bg-gray-100"
                      >
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>

                    {/* Hover Caption */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <h3 className="text-xl mb-2">{item.title}</h3>
                      <p className="text-gray-200 mb-3">by {item.designer}</p>
                      <div className="flex items-center space-x-4 text-sm">
                        <span className="flex items-center">
                          <Heart className="h-4 w-4 mr-1" />
                          {item.likes}
                        </span>
                        <span className="flex items-center">
                          <Pin className="h-4 w-4 mr-1" />
                          {item.pins}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Content (Always Visible) */}
                <div className="p-6">
                  <h3 className="text-lg mb-2 text-[#8D6E63]">{item.title}</h3>
                  <p className="text-gray-600 mb-3">by {item.designer}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span className="flex items-center">
                        <Heart className="h-4 w-4 mr-1" />
                        {item.likes}
                      </span>
                      <span className="flex items-center">
                        <Pin className="h-4 w-4 mr-1" />
                        {item.pins}
                      </span>
                    </div>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-teal-600 border-teal-600 hover:bg-teal-50"
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Load More */}
          <div className="text-center mt-12">
            <Button className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-3">
              Load More Designs
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}