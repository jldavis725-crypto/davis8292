import { useState } from "react";
import { Menu, Search, ShoppingCart, User, X } from "lucide-react";
import { Button } from "./ui/button";

interface HeaderProps {
  currentPage: "home" | "products" | "about" | "specials" | "gallery" | "contact";
  onNavigate: (page: "home" | "products" | "about" | "specials" | "gallery" | "contact") => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "home", label: "Home" },
    { id: "products", label: "Products" },
    { id: "about", label: "About Us" },
    { id: "specials", label: "Specials" },
    { id: "gallery", label: "Gallery" },
    { id: "contact", label: "Contact" }
  ] as const;

  const handleNavigation = (page: typeof navItems[number]["id"]) => {
    onNavigate(page);
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <h1 
              className="text-lg md:text-xl text-[#1a365d] cursor-pointer font-medium"
              onClick={() => handleNavigation("home")}
            >
              Brooks Town Home Furnishings
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex space-x-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavigation(item.id)}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  currentPage === item.id
                    ? "bg-[#1a365d] text-white"
                    : "text-[#2d3748] hover:text-[#1a365d] hover:bg-[#faf5f0]"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right side actions */}
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Search className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <ShoppingCart className="h-5 w-5" />
            </Button>
            
            {/* Mobile menu button */}
            <Button 
              variant="ghost" 
              size="icon" 
              className="lg:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden mt-4 pb-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-2 pt-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavigation(item.id)}
                  className={`text-left px-4 py-3 rounded-lg transition-colors ${
                    currentPage === item.id
                      ? "bg-[#1a365d] text-white"
                      : "text-[#2d3748] hover:text-[#1a365d] hover:bg-[#faf5f0]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
              
              {/* Mobile-only actions */}
              <div className="flex space-x-4 px-4 pt-4 border-t border-gray-200 mt-4">
                <Button variant="outline" size="sm" className="flex-1">
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
                <Button variant="outline" size="sm" className="flex-1">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Cart
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}