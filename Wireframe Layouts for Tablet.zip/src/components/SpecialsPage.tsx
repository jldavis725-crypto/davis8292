import { Star, Tag, Clock, Gift, TrendingDown, Calendar } from "lucide-react";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function SpecialsPage() {
  const flashSales = [
    {
      title: "Living Room Sets",
      discount: "40% OFF",
      description: "Complete your living space with our premium sofa and chair combinations.",
      image: "https://images.unsplash.com/photo-1663756915436-c6842b9d3eb0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzb2ZhJTIwbGl2aW5nJTIwcm9vbXxlbnwxfHx8fDE3NTkyMzgzOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      timeLeft: "2 Days",
      originalPrice: 2499,
      salePrice: 1499
    },
    {
      title: "Dining Sets",
      discount: "35% OFF", 
      description: "Elegant dining tables and chairs perfect for family gatherings.",
      image: "https://images.unsplash.com/photo-1712077717085-b7cd44227aef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaW5pbmclMjB0YWJsZSUyMGNoYWlyc3xlbnwxfHx8fDE3NTkxMzc0Mzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      timeLeft: "5 Days",
      originalPrice: 1899,
      salePrice: 1234
    },
    {
      title: "Bedroom Furniture",
      discount: "30% OFF",
      description: "Transform your bedroom with our luxury bed frames and dressers.",
      image: "https://images.unsplash.com/photo-1680503146454-04ac81a63550?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhiZWRyb29tJTIwZnVybml0dXJlJTIwYmVkfGVufDF8fHx8MTc1OTEzNzE0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      timeLeft: "1 Week",
      originalPrice: 1599,
      salePrice: 1119
    }
  ];

  const specialOffers = [
    {
      icon: <Tag className="h-8 w-8" />,
      title: "Buy 2, Get 1 Free",
      discount: "SAVE 33%",
      description: "Mix and match any chairs in our collection. Perfect for updating your dining room or adding extra seating."
    },
    {
      icon: <TrendingDown className="h-8 w-8" />,
      title: "Floor Model Sale",
      discount: "UP TO 50% OFF",
      description: "Gently used display models at incredible prices. Each piece has been carefully maintained in our showroom."
    },
    {
      icon: <Star className="h-8 w-8" />,
      title: "VIP Customer Sale",
      discount: "EXTRA 15% OFF",
      description: "Exclusive additional discount for our VIP members on top of existing sales. Join our VIP program today!"
    }
  ];

  const clearanceItems = [
    {
      title: "Accent Chair",
      image: "https://images.unsplash.com/photo-1631122989854-86a2af6c96d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY2NlbnQlMjBjaGFpciUyMGxpdmluZyUyMHJvb218ZW58MXx8fHwxNzU5MjM5MzY2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      originalPrice: 599,
      salePrice: 299
    },
    {
      title: "Coffee Table",
      image: "https://images.unsplash.com/photo-1710429243521-e7c1527e7d83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjB0YWJsZSUyMGxpdmluZyUyMHJvb218ZW58MXx8fHwxNzU5MjM5NDAyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      originalPrice: 799,
      salePrice: 449
    },
    {
      title: "Bookshelf",
      image: "https://images.unsplash.com/photo-1615461037394-5b4987dada30?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib29rc2hlbGYlMjBmdXJuaXR1cmV8ZW58MXx8fHwxNzU5MTM3OTY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      originalPrice: 499,
      salePrice: 249
    },
    {
      title: "Side Table",
      image: "https://images.unsplash.com/photo-1680503146454-04ac81a63550?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHhiZWRyb29tJTIwZnVybml0dXJlJTIwYmVkfGVufDF8fHx8MTc1OTEzNzE0Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      originalPrice: 349,
      salePrice: 199
    }
  ];

  const upcomingEvents = [
    {
      icon: <Calendar className="h-6 w-6" />,
      title: "Presidents Day Weekend Sale",
      date: "February 17-19, 2024",
      description: "Massive storewide savings on all furniture categories."
    },
    {
      icon: <Gift className="h-6 w-6" />,
      title: "Spring Renewal Event",
      date: "March 15-31, 2024",
      description: "Trade in your old furniture for credit towards new pieces."
    },
    {
      icon: <Star className="h-6 w-6" />,
      title: "Customer Appreciation Night",
      date: "April 12, 2024",
      description: "Exclusive after-hours shopping with special discounts and refreshments."
    }
  ];

  return (
    <div className="pt-20 bg-white min-h-screen">
      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-red-600 to-orange-500 text-white">
        <div className="container mx-auto px-6 text-center">
          <h1 className="text-4xl mb-4">Special Offers & Sales</h1>
          <p className="text-xl mb-8">
            Incredible savings on quality furniture for every room in your home
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-red-600 hover:bg-gray-100">
              Shop All Sales
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-red-600">
              Sign Up for Alerts
            </Button>
          </div>
        </div>
      </section>

      {/* Flash Sales */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4 text-[#1a365d]">Flash Sales</h2>
            <p className="text-xl text-[#718096]">Limited time offers - don't miss out!</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {flashSales.map((sale, index) => (
              <Card key={index} className="overflow-hidden border-2 border-red-200">
                <div className="relative">
                  <ImageWithFallback
                    src={sale.image}
                    alt={sale.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <div className="bg-red-500 text-white px-3 py-1 rounded-full">
                      <Clock className="h-4 w-4 inline mr-1" />
                      {sale.timeLeft}
                    </div>
                  </div>
                  <div className="absolute top-4 right-4">
                    <div className="bg-yellow-400 text-black px-3 py-1 rounded-full">
                      {sale.discount}
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-[#1a365d]">{sale.title}</h3>
                  <div className="text-3xl text-red-600 mb-4">{sale.discount}</div>
                  <p className="text-[#718096] mb-6">{sale.description}</p>
                  
                  <div className="flex items-center gap-3 mb-6">
                    <span className="text-2xl text-red-600">${sale.salePrice.toLocaleString()}</span>
                    <span className="text-[#718096] line-through">${sale.originalPrice.toLocaleString()}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <Button className="w-full bg-red-500 hover:bg-red-600 text-white">
                      Shop Now
                    </Button>
                    <Button variant="outline" className="w-full text-[#1a365d] border-[#1a365d] hover:bg-[#1a365d] hover:text-white">
                      Learn More
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Special Offers */}
      <section className="py-16 bg-[#edf2f7]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4 text-[#1a365d]">Special Offers</h2>
            <p className="text-xl text-[#718096]">Amazing deals you won't find anywhere else!</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {specialOffers.map((offer, index) => (
              <Card key={index} className="text-center p-8 hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <div className="text-orange-500 mb-4 flex justify-center">
                    {offer.icon}
                  </div>
                  <div className="text-2xl text-orange-600 mb-2">{offer.discount}</div>
                  <h3 className="text-xl mb-4 text-[#1a365d]">{offer.title}</h3>
                  <p className="text-[#718096] mb-6">{offer.description}</p>
                  <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Clearance Center */}
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4 text-[#1a365d]">Clearance Center</h2>
            <p className="text-xl text-[#718096]">Final markdowns - limited quantities available!</p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-6">
            {clearanceItems.map((item, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="relative">
                  <ImageWithFallback
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-2 right-2">
                    <div className="bg-red-500 text-white px-2 py-1 rounded text-sm">
                      CLEARANCE
                    </div>
                  </div>
                </div>
                
                <CardContent className="p-6">
                  <h3 className="text-lg mb-3 text-[#1a365d]">{item.title}</h3>
                  
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-2xl text-red-600">${item.salePrice.toLocaleString()}</span>
                    <span className="text-[#718096] line-through">${item.originalPrice.toLocaleString()}</span>
                  </div>
                  
                  <div className="space-y-2">
                    <Button className="w-full bg-red-500 hover:bg-red-600 text-white">
                      Add to Cart
                    </Button>
                    <Button variant="outline" className="w-full text-[#1a365d] border-[#1a365d]">
                      Quick View
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-16 bg-[#edf2f7]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl mb-4 text-[#1a365d]">Upcoming Sales & Events</h2>
            <p className="text-xl text-[#718096]">Mark your calendar for these special events!</p>
          </div>
          
          <div className="max-w-4xl mx-auto space-y-6">
            {upcomingEvents.map((event, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-start gap-4">
                  <div className="text-orange-500 mt-1">
                    {event.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl mb-2 text-[#1a365d]">{event.title}</h3>
                    <p className="text-orange-600 mb-2">{event.date}</p>
                    <p className="text-[#718096]">{event.description}</p>
                  </div>
                  <Button variant="outline" className="text-[#1a365d] border-[#1a365d]">
                    Remind Me
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-[#1a365d] text-white">
        <div className="container mx-auto px-6 text-center">
          <Gift className="h-16 w-16 text-orange-400 mx-auto mb-6" />
          <h2 className="text-3xl mb-4">Never Miss a Deal!</h2>
          <p className="text-xl mb-8 text-gray-300">
            Sign up for our newsletter and be the first to know about sales, new arrivals, and exclusive offers.
          </p>
          <div className="max-w-lg mx-auto flex flex-col sm:flex-row gap-4">
            <Input
              type="email"
              placeholder="Enter your email address"
              className="flex-1 px-4 py-3 text-[#2d3748] bg-white border-0 placeholder:text-[#718096] text-base"
            />
            <Button className="bg-[#d69e2e] hover:bg-[#b7791f] text-white px-8 py-3 whitespace-nowrap">
              Subscribe Now
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}