import { useState } from "react";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { HomePage } from "./components/HomePage";
import { ProductsPage } from "./components/ProductsPage";
import { AboutPage } from "./components/AboutPage";
import { SpecialsPage } from "./components/SpecialsPage";
import { GalleryPage } from "./components/GalleryPage";
import { ContactPage } from "./components/ContactPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState<"home" | "products" | "about" | "specials" | "gallery" | "contact">("home");

  const handleNavigate = (page: "home" | "products" | "about" | "specials" | "gallery" | "contact") => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage />;
      case "products":
        return <ProductsPage />;
      case "about":
        return <AboutPage />;
      case "specials":
        return <SpecialsPage />;
      case "gallery":
        return <GalleryPage />;
      case "contact":
        return <ContactPage />;
      default:
        return <HomePage />;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      
      <main>
        {renderCurrentPage()}
      </main>

      <Footer variant={currentPage === "contact" ? "contact" : "default"} />
    </div>
  );
}